<?php
include("db.php");
$proid=$_POST['ITEM'];
$itemnumber=$_POST['itemnumber'];
$get = mysql_query("SELECT * FROM inventory WHERE id='$proid'");
$row = mysql_fetch_array($get);
$qtyleft = $row['qtyleft'];
$qty_sold= $row['qty_sold'];
$qty = $itemnumber + $qtyleft;
mysql_query("UPDATE inventory SET qtyleft='$qty' WHERE id='$proid'");
header("location: tableedit.php#page=addproitem");
?>