<?php
include("db.php");
$proname=$_POST['proname'];
$price=$_POST['price'];
$qty=$_POST['qty']; 
$description=$_POST['description'];

 
$imagename=$_FILES["myimage"]["name"]; 
//Insert the image name and image content in image_table
$insert_image="INSERT INTO inventory (item, price, qtyleft,imagename,description) VALUES('$proname', '$price','$qty','$imagename','$description')";


if($_POST)
{
// $_FILES["file"]["error"] is HTTP File Upload variables $_FILES["file"] "file" is the name of input field you have in form tag.

if ($_FILES["myimage"]["error"] > 0)
{
// if there is error in file uploading
echo "Return Code: " . $_FILES["myimage"]["error"] . "<br />";

}
else
{
// check if file already exit in "images" folder.
if (file_exists("images/" . $_FILES["myimage"]["name"]))
{
echo $_FILES["myimage"]["name"] . " already exists. ";
}
else
{  //move_uploaded_file function will upload your image.  if you want to resize image before uploading see this link http://b2atutorials.blogspot.com/2013/06/how-to-upload-and-resize-image-for.html
if(move_uploaded_file($_FILES["myimage"]["tmp_name"],"images/" . $_FILES["myimage"]["name"]))
{
// If file has uploaded successfully, store its name in data base
	$insert_image="INSERT INTO inventory (item, price, qtyleft,imagename,description) VALUES('$proname', '$price','$qty','$imagename','$description')";

if(mysql_query($insert_image))

{
echo "Stored in: " . "images/" . $_FILES["myimage"]["name"];
}
else
{
echo 'File name not stored in database';
}
}
}


}
}
//mysql_query("INSERT INTO inventory () VALUES (')");
header("location: tableedit.php#page=addpro");
?>